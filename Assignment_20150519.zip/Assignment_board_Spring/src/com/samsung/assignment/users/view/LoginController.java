package com.samsung.assignment.users.view;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.google.gson.Gson;
import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.users.impl.UserDAO;
import com.samsung.assignment.users.vo.UserVO;

public class LoginController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		
		UserVO vo = new UserVO();
		vo.setUser_id(user_id);
		vo.setPassword(password);
		UserDAO dao = new UserDAO();
		
		UserVO loginUser = dao.login(vo);
		String msg = "";
		if(loginUser.getUser_id()==null){
			msg = "아이디를 확인하세요";
			mav.addObject("msg", msg);
		}else if(loginUser.getPassword().equals("uncorrect")){
			msg = "비밀번호를 확인하세요";
			mav.addObject("inputId", user_id);
			mav.addObject("msg", msg);
		}else{
			HttpSession session = request.getSession();
			session.setAttribute("user_id", loginUser.getUser_id());
			session.setAttribute("user_name", loginUser.getUser_name());
			msg = "성공";
		}
		// 게시글 가져가기
		mav.setViewName("getBoardList.do");
		return mav;
	}
}
