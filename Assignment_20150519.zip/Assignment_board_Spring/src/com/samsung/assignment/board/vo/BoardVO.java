package com.samsung.assignment.board.vo;

import java.sql.Date;

public class BoardVO {
	private int board_seq;
	private String board_title;
	private String board_content;
	private String user_id;
	private int board_cnt;
	private Date board_regdate;
	private int board_parentSeq;
	private int board_step;
	private int board_lvl;
	public BoardVO() {
	}
	public BoardVO(int board_seq, String board_title, String board_content,
			String user_id, int board_cnt, Date board_regdate,
			int board_parentSeq, int board_step, int board_lvl) {
		super();
		this.board_seq = board_seq;
		this.board_title = board_title;
		this.board_content = board_content;
		this.user_id = user_id;
		this.board_cnt = board_cnt;
		this.board_regdate = board_regdate;
		this.board_parentSeq = board_parentSeq;
		this.board_step = board_step;
		this.board_lvl = board_lvl;
	}
	public int getBoard_seq() {
		return board_seq;
	}
	public void setBoard_seq(int board_seq) {
		this.board_seq = board_seq;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getBoard_cnt() {
		return board_cnt;
	}
	public void setBoard_cnt(int board_cnt) {
		this.board_cnt = board_cnt;
	}
	public Date getBoard_regdate() {
		return board_regdate;
	}
	public void setBoard_regdate(Date board_regdate) {
		this.board_regdate = board_regdate;
	}
	public int getBoard_parentSeq() {
		return board_parentSeq;
	}
	public void setBoard_parentSeq(int board_parentSeq) {
		this.board_parentSeq = board_parentSeq;
	}
	public int getBoard_step() {
		return board_step;
	}
	public void setBoard_step(int board_step) {
		this.board_step = board_step;
	}
	public int getBoard_lvl() {
		return board_lvl;
	}
	public void setBoard_lvl(int board_lvl) {
		this.board_lvl = board_lvl;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BoardVO [board_seq=");
		builder.append(board_seq);
		builder.append(", board_title=");
		builder.append(board_title);
		builder.append(", board_content=");
		builder.append(board_content);
		builder.append(", user_id=");
		builder.append(user_id);
		builder.append(", board_cnt=");
		builder.append(board_cnt);
		builder.append(", board_regdate=");
		builder.append(board_regdate);
		builder.append(", board_parentSeq=");
		builder.append(board_parentSeq);
		builder.append(", board_step=");
		builder.append(board_step);
		builder.append(", board_lvl=");
		builder.append(board_lvl);
		builder.append("]");
		return builder.toString();
	}
}
