package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;

/**
 * 게시글을 삭제하기 위한 컨트롤러
 * 실제로 게시글을 삭제하지는 않으며, 제목을 '삭제된 글입니다'라고 update한 뒤 조회하지 못하도록 함
 * @author student
 *
 */
public class DeleteBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		
		BoardDAO dao = new BoardDAO();
		
		// 답글이 있는 글인지 조회
		boolean canDelete = dao.deleteCheckBoard(vo);
		if(canDelete){
			// 답글이 없으면 게시글 삭제
			boolean done = dao.deleteBoard(vo);
			if(done){
				mav.addObject("msg", "삭제 완료");
				mav.setViewName("getBoardList.do");
				return mav;
			}else{
				mav.addObject("msg", "삭제 도중 에러 발생!");
				mav.addObject("board_seq", board_seq);
				mav.setViewName("getBoardView.do");
				return mav;
			}
		}else{
			// 답글이 있는 글이면 게시글 삭제하지 못하게 함
			request.setAttribute("msg", "답글이 있는 글은 삭제할 수 없습니다");
			mav.addObject("board_seq", board_seq);
			mav.setViewName("getBoardView.do");
			return mav;
		}
	}

}
