package com.samsung.assignment.board.view;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.AdvancedPageUtility;

public class GetBoardListController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		int pageNum = 1;
		if(request.getParameter("pageNo")!=null){
			pageNum = Integer.parseInt(request.getParameter("pageNo"));
		}
		BoardDAO dao = new BoardDAO();
		int interval = 10;
		// 게시글 전체 가져오기
		ArrayList<BoardVO> boardList = dao.list(pageNum, interval);
		// 게시글 수 가져오기
		int total = dao.listCount();
		// total이 0이면 1, 아니면 total
		total = total==0?1:total;
		try {
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total, pageNum, "images/");
			mav.addObject("pageLink", bar.getPageBar());
			mav.addObject("boardList", boardList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		mav.setViewName("board.jsp");
		return mav;
	}
}
