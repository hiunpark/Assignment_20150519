package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;

public class UpdateSaveController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		String board_title = request.getParameter("board_title"); 
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		
		BoardDAO dao = new BoardDAO();
		boolean done = dao.updateBoard(vo);
		mav.addObject("", done);
		return mav;
	}
}
