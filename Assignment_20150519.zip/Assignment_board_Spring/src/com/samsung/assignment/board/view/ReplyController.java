package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;

/**
 * 
 * @author student
 *
 */
public class ReplyController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		int board_seq = Integer.parseInt(request.getParameter("board_seq"));
		BoardVO vo = new BoardVO();
		vo.setBoard_seq(board_seq);
		
		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoardView(vo);
		int grandParentBoardSeq = dao.selectBoardSeq(board_seq);
		// 원글 넣어서 돌려보내기
		mav.addObject("parentBoard", board);
		// 가장 첫번째 글도 함께 넣기
		mav.addObject("grandParentBoardSeq", grandParentBoardSeq);
		mav.setViewName("reply.jsp");
		return mav;
	}

}
