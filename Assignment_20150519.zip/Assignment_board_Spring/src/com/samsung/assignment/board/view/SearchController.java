package com.samsung.assignment.board.view;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
import com.samsung.assignment.controller.AdvancedPageUtility;

public class SearchController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		int pageNum = 1;
		if(request.getParameter("pageNo")!=null){
			pageNum = Integer.parseInt(request.getParameter("pageNo"));
		}
		String search = request.getParameter("option");
		String content = request.getParameter("content");
		ArrayList<BoardVO> boardList = new ArrayList<>();
		BoardDAO dao = new BoardDAO();
		int interval = 10;
		int total = 0;
		// 제목과 아이디에 대해 검색
		if(search.equals("title")){
			boardList = dao.searchByTitle(content, pageNum, interval);
			// 게시글 수 가져오기
			total = dao.searchByTitleCount(search);
		}else if(search.equals("content")){
			boardList = dao.searchByContent(content, pageNum, interval);
			total = dao.searchByContentCount(content);
		}
		// total이 0이면 1, 아니면 total
		total = total==0?1:total;
		try {
			AdvancedPageUtility bar = new AdvancedPageUtility(interval, total, pageNum, "images/");
			mav.addObject("pageLink", bar.getPageBar());
			mav.addObject("boardList", boardList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		mav.setViewName("board.jsp");
		return mav;
	}
}
