package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;
/**
 * 새글을 저장하는 Controller
 * @author student
 *
 */
public class InsertNewBoardController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		HttpSession session = request.getSession();
		if(session.getAttribute("user_id")==null){
			mav.addObject("msg", "세션이 만료되어 로그아웃되었습니다");
			mav.setViewName("getBoardList.do");
			return mav;
		}
		
		String user_id = (String) session.getAttribute("user_id");
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setUser_id(user_id);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		
		BoardDAO dao = new BoardDAO();
		boolean done = dao.insertNewBoard(vo);
		if(done){
			mav.setViewName("getBoardList.do");
			return mav;
		}else{
			mav.addObject("msg", "게시글 DB에 저장 실패!");
			mav.addObject("writingBoard", vo);
			mav.setViewName("write.jsp");
			return mav;
		}
	}
}
