package com.samsung.assignment.board.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.samsung.assignment.board.impl.BoardDAO;
import com.samsung.assignment.board.vo.BoardVO;

public class InsertReplyController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		HttpSession session = request.getSession();
		if(session.getAttribute("user_id")==null){
			mav.addObject("msg", "세션이 만료되어 로그아웃되었습니다");
			mav.setViewName("getBoardList.do");
			return mav;
		}
		
		String user_id = (String) session.getAttribute("user_id");
		int board_grandParentSeq = Integer.parseInt(request.getParameter("board_grandParentSeq"));
		int board_parentSeq = Integer.parseInt(request.getParameter("board_parentSeq"));
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
		
		BoardVO vo = new BoardVO();
		vo.setUser_id(user_id);
		vo.setBoard_title(board_title);
		vo.setBoard_content(board_content);
		vo.setBoard_parentSeq(board_grandParentSeq);
		
		// step과 lvl을 가져와서 1씩 증가시키기
		BoardDAO dao = new BoardDAO();
		// 바로 윗글의 step을 가져오기
		int parentStep = dao.selectMaxStep(board_parentSeq);
		// 바로 윗글에 대한 lvl을 가져오기
		int parentLvl = dao.selectLvl(board_parentSeq);
		vo.setBoard_step(parentStep+1);
		vo.setBoard_lvl(parentLvl+1);
		
		// 새로 생성되는 답글들의 아래 답글들 step을 +1시키는 메서드
		boolean done = true;
		done = dao.updateStep(board_grandParentSeq, parentStep);
		BoardVO board = dao.insertReplyBoard(vo);
		// 삽입 완료 후 작성된 게시글 페이지로 이동
		if(board!=null && done){
			mav.setViewName("getBoardView.do?board_seq="+board.getBoard_seq());
			return mav;
		}else{
			mav.addObject("msg", "답글 저장 중 에러 발생");
			mav.addObject("writingBoard", vo);
			mav.setViewName("reply.jsp");
			return mav;
		}
	}
}
